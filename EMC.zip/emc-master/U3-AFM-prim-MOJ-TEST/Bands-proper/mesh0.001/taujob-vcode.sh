#!/bin/bash
# submit the job on taurus to the slurm batch system with
# sbatch taujob.sh
#SBATCH -J U3AFM
#SBATCH --time=4:00:00         # walltime
#SBATCH --mem-per-cpu=2048M      # memory per CPU core
#SBATCH --output=out
#SBATCH --error=err
#SBATCH --partition=haswell,sandy,west
#SBATCH	--mail-type=all
#SBATCH --ntasks=24             # number of processor cores (i.e. tasks)
#SBATCH --nodes=1
#SBATCH -A p_transphemat

#BINARY=/home/h6/mapo310b/vcode/5.3/vcode.std
BINARY=/home/mapo310b/vcode/5.4.4/vcode.ncl

# load modules
module load modenv/both
module load modenv/classic
module load vasp/5.4.4

# submit the job to the slurm batch system, srun=mpirun
srun $BINARY

